<?php
session_start();
if(isset($_COOKIE["USER"]) || isset($_SESSION['USER']))
{
    echo "<script>window.location.href='index.php';</script>";
    die();
}
if(isset($_COOKIE["ADMIN"]) || isset($_SESSION['ADMIN']))
{
    echo "<script>window.location.href='admin/index.php';</script>";
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="img/icon/icon.png" type="image/x-icon">
    <link rel="stylesheet" href="css/login-style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>realme - login</title>
</head>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="index.php">Home</a>
            <a href="register.php">Register</a>
            <a href="admin/login.php">Admin Login</a>
        </div>  
    </header>
    <div class="container">
        <div class="login-text">Login</div>
        <div class="login-form">
            <form method="post">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="submit" value="Login" name="login">
                <p>Don't have an account? <a href="register.php">Register</a></p>
            </form> 
        </div>       
    </div>
</body>
</html>

<?php
   include 'config/connection.php';
    
    if(isset($_POST["login"]))
    {
        $username=$_POST['username']; 
        $password=$_POST['password']; 
       
        $query=" SELECT * FROM `user-register` WHERE `PASSWORD` like '$password' and USERNAME like '$username' ";
        $query_run=mysqli_query($conn,$query);

        while($row=$query_run->fetch_assoc())
        {
            if($row)
            {
                $_SESSION["USER"] = $row["USERNAME"];
                setcookie("USER",$row["USERNAME"],time()+60*60*24*30);
                echo "<script>window.location.href='index.php';</script>";
                die();
            }
        }
       
    }
?>