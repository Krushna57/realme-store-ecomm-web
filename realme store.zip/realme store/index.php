<?php
    session_start();
    if(isset($_COOKIE["USER"]) || isset($_COOKIE["ADMIN"]))
    {
        if(!isset($_SESSION["USER"]))
        {
            $_SESSION["USER"] = $_COOKIE["USER"];
        }
    }
    include 'config/connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=0.3">
    <link rel="shortcut icon" href="img/icon/icon.png" type="image/x-icon">
    <link rel="stylesheet" href="css/index-style.css">
    <title>realme (india) - Dare to leap</title> 
</head>
<style>
     .badge
    {
        height:20px;
        width:20px;
        border-radius:50%;
        background:red;
        text-align:center;
        line-height:20px;
        position: absolute;
        top:0;
        left:100px;
    }
</style>
<body>
    <div class="top-header">
        <?php
        if(isset($_COOKIE['USER']))
        {
            ?>
            <a href="profile/profile.php"><img src="img/icon/user.png" height="25px" width="25px" alt="profile" title="profile"></a>
            <?php
        }
        else
        {
            ?>
            <a href="login.php"><img src="img/icon/user.png" height="25px" width="25px" alt="login" title="Login"></a>
            <?php
        }
        ?>
        <div>
            <img src="img/icon/shopping-cart.png" height="25px" width="25px" alt="cart" title="Cart" onclick="window.location.href='mycart.php'">
            <?php
                if(isset($_COOKIE['USER']))
                {
                    $username = $_COOKIE["USER"];
                    $query = "SELECT * FROM `cart` WHERE `USERNAME` LIKE '$username'";
                    $run = mysqli_query($conn,$query);
                    if($run)
                    {
                        $row_count = mysqli_num_rows($run);
                        if($row_count > 0)
                        {
                            ?>
                                <div class="badge" onclick="window.location.href='mycart.php'"><?php echo $row_count;?></div>
                            <?php
                        }
                    }
                }
            ?>
        </div>
        <img src="img/icon/order.png" height="25px" width="25px" alt="my order" title="My Order" onclick="window.location.href='payment/order-history.php'">
    </div>
    <header>
        <div class="logo">realme</div>
        <div class="menu-bar">
            <a href="#">Home</a>
            <a href="contact/">Contact</a>
        </div>
    </header>
    <div class="container">
        <section id="slider">    
            <img src="img/slide/slide1.jpg" id="img i1" width="100%" alt="">
            <img src="img/slide/slide2.jpg" id="img i2" width="100%" alt="">
            <img src="img/slide/slide3.jpg" id="img i3" width="100%" alt="">
            <img src="img/slide/slide4.jpg" id="img i4" width="100%" alt="">
            <img src="img/slide/slide5.jpg" id="img i5" width="100%" alt="">
            <img src="img/slide/slide6.jpg" id="img i6" width="100%" alt="">
            <img src="img/slide/slide7.jpg" id="img i6" width="100%" alt="">
            <img src="img/slide/slide8.jpg" id="img i6" width="100%" alt="">
            <img src="img/slide/slide9.jpg" id="img i6" width="100%" alt="">
            <img src="img/slide/slide10.jpg" id="img i6" width="100%" alt="">
        </section>
        <section class="row">
            <?php
                $query = "SELECT * FROM `realme-smartphones`";
                $run = mysqli_query($conn,$query);
                if($run)
                {
                    while($row = mysqli_fetch_array($run))
                    {
                        $stock = $row["IN-STOCK"];
                        $offer = $row["OFFER"];
                        $original_price = $row["PRICE"];
                        $saved_money = round($offer * $original_price / 100);
                        $price = $original_price - $saved_money;
                    ?>
                       <form action="view/about-smartphone.php" method="post">
                        <div class="cols">
                                <figure>
                                    <center>
                                        <img src="img/smartphones/<?php echo $row['IMAGE']; ?>" height="150px" alt="image">
                                    </center>
                                    <figcaption>  
                                        <?php echo $row['NAME']; ?> <br>
                                        <b>₹ <?php echo $price; ?></b>
                                        <s><?php echo $original_price; ?></s><br>
                                        <font color="green"><b><?php echo $offer." % off ";?></b></font>
                                        <b><font color="green">, Save ₹ <?php echo $saved_money; ?></font></b> <br>
                                        <?php
                                            if($stock <= 0)
                                            {
                                                echo '<b style="color:red;">Out of stock<br></b>';
                                            }
                                            else if($stock <= 5)
                                            {
                                               echo '<b style="color:red;">Only '.$stock.' left<br></b>';
                                            }
                                            else
                                            {
                                                echo "<br>";
                                            }
                                        ?>
                                        <input type="hidden" name="id" value="<?php echo $row['ID'];?>">
                                        <input type="submit" value="VIEW" name="view">
                                    </figcaption>
                                </figure>
                            </div>
                       </form>
                    <?php
                    }
                }
                $query = "SELECT * FROM `realme-smartwatch`";
                $run = mysqli_query($conn,$query);
                if($run)
                {
                    while($row = mysqli_fetch_array($run))
                    {
                        $stock = $row["IN-STOCK"];
                        $offer = $row["OFFER"];
                        $original_price = $row["PRICE"];
                        $saved_money = round($offer * $original_price / 100);
                        $price = $original_price - $saved_money;
                    ?>
                       <form action="view/about-smartwatch.php" method="post">
                        <div class="cols">
                                <figure>
                                    <center>
                                        <img src="img/watch/<?php echo $row['IMAGE']; ?>" height="150px" alt="image">
                                    </center>
                                    <figcaption>  
                                        <?php echo $row['NAME']; ?> <br>
                                        <b>₹ <?php echo $price; ?></b>
                                        <s><?php echo $original_price; ?></s><br>
                                        <font color="green"><b><?php echo $offer." % off ";?></b></font>
                                        <b><font color="green">, Save ₹ <?php echo $saved_money; ?></font></b> <br>
                                        <?php
                                            if($stock <= 0)
                                            {
                                                echo '<b style="color:red;">Out of stock<br></b>';
                                            }
                                            else if($stock <= 5)
                                            {
                                               echo '<b style="color:red;">Only '.$stock.' left<br></b>';
                                            }
                                            else
                                            {
                                                echo "<br>";
                                            }
                                        ?>
                                        <input type="hidden" name="id" value="<?php echo $row['ID'];?>">
                                        <input type="submit" value="VIEW" name="view">
                                    </figcaption>
                                </figure>
                            </div>
                       </form>
                    <?php
                    }
                }

            ?>
        </section>
        
        <!-- <section class="banner">
            <img src="img/slide/slide6.jpg" width="100%" alt="">
        </section> -->
    </div>
    <hr>
    <footer>
        <ul class="support">
            <li style="font-size: 14pt;">Support</li>
            <li><a href="">FAQ</a></li>
            <li><a href="">User Support</a></li>
            <li><a href="">Service Center</a></li>
            <li><a href="">Realme Coins</a></li>
            <li><a href=""> Management</a></li>
        </ul>

        <ul class="about_realme" >
            <li style="font-size: 14pt;">About Realme</li>
            <li><a href="">FAQ</a></li>
            <li><a href="">User Support</a></li>
            <li><a href="">Service Center</a></li>
            <li><a href="">Realme Coins</a></li>
            <li><a href=""> Management</a></li>
        </ul>

        <ul class="contact_realme" >
            <li style="font-size: 14pt;">Contact Realme</li>
            <li><a href="mailto:service@realme.com">service@realme.com</a></li>
            <li><a href="mailto:orders.in@realme.com">orders.in@realme.com</a></li>
        </ul>
        <ul class="stay_with_us" >
            <li style="font-size: 14pt;">Stay With Us</li>
            <li><a href=""><img src="img/icon/instagram.png" alt="instagram" title="Instagram"></a></li>
            <li><a href=""><img src="img/icon/facebook.png" alt="facebook" title="Facebook"></a></li>
            <li><a href=""><img src="img/icon/youtube.png" alt="youtube" title="YouTube"></a></li>
        </ul>
    </footer>
    <p id="copyright">© 2018-2022 realme. All Rights Reserved.</p>
</body>
</html>
<script>
    x = 0;
    setInterval(changeSlideImg,5000);
    function changeSlideImg()
    {
        if(x== -1000)
            x=0;
        slider.style.transform="translateX("+x+"%)";
        x = x-100;
    }
</script>