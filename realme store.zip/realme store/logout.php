<?php
    session_start();
    setcookie("USER","",time()-60);
    unset($_SESSION["USER"]);
    session_unset();
    session_destroy();
    echo "
    <script>
        window.location.href = 'index.php';
    </script>
    ";
    die();
?>
