<?php
session_start();
if(isset($_COOKIE['USERNAME']))
{
    if(!isset($_SESSION['USERNAME']))
    {
        $_SESSION['USERNAME'] = $_COOKIE['USERNAME'];
    }
}
if(!isset($_SESSION["USERNAME"]))
{
    echo "
    <script>
        alert('please login to continue...');
        window.location.href = '../login.php';
    </script>
    ";
    die();
}

if(isset($_POST['send-msg']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user_details = "User Name : $name \nUser Email: $email \n";
    $message = $user_details."\r\n".$_POST['msg'];
    $message = wordwrap($message,70);
    $to = "educationforever57@gmail.com";
    $subject = "Realme India - Contact";
     
    $result = mail($to,$subject,$message);
    if($result)
    {
        echo "
        <script>
            alert('Dear $name, thank you for contacting us,we will reply you soon - Team Realme india ');
            window.location.href = 'index.html';
        </script>
        ";
        die();
    }
    else
    {
        echo"Failed to contact....!";
    }
}

?>