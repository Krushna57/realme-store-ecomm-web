<?php
session_start();
if(isset($_COOKIE["ADMIN"]) || isset($_SESSION['ADMIN']))
{
    echo "<script>window.location.href='index.php';</script>";
    die();
}
if(isset($_COOKIE["USER"]) || isset($_SESSION['USER']))
{
    echo "<script>window.location.href='../index.php';</script>";
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/login-style.css">
    <title>realme - admin login</title>
</head>

<body>
<header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="../index.php">Home</a>
            <a href="../login.php">Login</a>
            <a href="../register.php">Register</a>
        </div>  
    </header>

    <div class="container">
        <div class="login-text">Admin Login</div>
        <div class="login-form">
            <form method="post">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="submit" value="Login" name="login">
            </form> 
        </div>       
    </div>
</body>
</html>

<?php
   include '../config/connection.php';
    
    if(isset($_POST["login"]))
    {
        $username=$_POST['username']; 
        $password=$_POST['password']; 
       
        $query=" SELECT * FROM `admin-login` WHERE `PASSWORD` like '$password' and `USERNAME` like '$username' ";
        $query_run=mysqli_query($conn,$query);

        if($query_run)
        {
            if(mysqli_num_rows($query_run)>0)
            {
                $row = mysqli_fetch_array($query_run);
                $_SESSION["ADMIN"] = $row["USERNAME"];
                setcookie("ADMIN",$row["USERNAME"],time()+60*60*24*30);
                echo "<script>window.location.href='index.php';</script>";
                die();
            }
            else
            {
                echo "<script>alert('Invalid Username Or Password....');</script>";
            }
        }
       
       
    }
?>