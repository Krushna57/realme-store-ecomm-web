<?php
    session_start();
    if(isset($_COOKIE["ADMIN"]) || isset($_SESSION["ADMIN"]))
    {
        if(!isset($_SESSION["ADMIN"]))
        {
            $_SESSION["ADMIN"] = $_COOKIE["ADMIN"];
        }
    }
    else
    {
        echo "
            <script>
                window.location.href='login.php';
            </script>
        ";
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/update-products-style.css">
    <title>Realme - all products</title>
</head>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="../index.php">Home</a>
            <a href="index.php">Dashboard</a>
            <a href="user-orders.php">User Order</a>
            <a href="add-product.php">Add Product</a>
            <a href="remove-products.php">Remove Product</a>
            <a href="update-products.php">Update Product</a>
            <a href="all-products.php">All Products</a>
        </div>  
    </header>
    <div class="container" id="cont">
        <div class="sub-container">
            <header>
                <span>
                    REALME SMARTPHONE
                </span>
            </header>
            <table cellspacing="0" cellpadding="5" border>
                <tr>
                    <th>SR NO</th>
                    <th>PRODUCT NAME</th>
                    <th>IN STOCK</th>
                    <th>OFFER </th>
                    <th>RAM</th>
                    <th>STORAGE</th>
                    <th>CAMERA</th>
                    <th>DISPLAY</th>
                    <th>PRICE</th>
                </tr>
                <?php
                    include '../config/connection.php';
                    $query = "SELECT * FROM `realme-smartphones`";
                    $run = mysqli_query($conn,$query);

                    if($run)
                    {
                        $count = 0;
                        while($row = mysqli_fetch_array($run))
                        {
                            $count = $count + 1;
                        ?>
                        <tr>
                            <td><?php echo $count; ?></td>
                            <td><?php echo $row['NAME']; ?></td>
                            <td><?php echo $row['IN-STOCK']; ?></td>
                            <td><?php echo $row['OFFER']."%"; ?> </td>
                            <td><?php echo $row['RAM']; ?> </td>
                            <td><?php echo $row['INTERNAL-STORAGE']; ?> </td>
                            <td><?php echo $row['CAMERA']; ?> </td>
                            <td><?php echo $row['DISPLAY']; ?> </td>
                            <td><?php echo $row['PRICE']; ?> </td>
                        </tr>
                        <?php
                        }
                    }
                ?>
            </table>
        </div>
        <div class="sub-container">
            <header>
                <span>
                    REALME SMARTWATCH
                </span>
            </header>
            <table cellspacing="0" cellpadding="5" border>
                <tr>
                    <th>SR NO</th>
                    <th>PRODUCT NAME</th>
                    <th>DISPLAY</th>
                    <th>BATTERY</th>
                    <th>OFFER </th>
                    <th>IN STOCK</th>
                    <th>PRICE</th>
                </tr>
                <?php
                    $query = "SELECT * FROM `realme-smartwatch`";
                    $run = mysqli_query($conn,$query);

                    if($run)
                    {
                        $count = 0;
                        while($row = mysqli_fetch_array($run))
                        {
                            $count = $count + 1;
                        ?>
                        <tr>
                            <td><?php echo $count; ?></td>
                            <td><?php echo $row['NAME']; ?></td>
                            <td><?php echo $row['DISPLAY']; ?></td>
                            <td><?php echo $row['BATTERY']; ?></td>
                            <td><?php echo $row['OFFER']."%"; ?> </td>
                            <td><?php echo $row['IN-STOCK']; ?></td>
                            <td><?php echo $row['PRICE']; ?> </td>
                        </tr>
                        <?php
                        }
                    }
                ?>
            </table>
        </div>
    </div>