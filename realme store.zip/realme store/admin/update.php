<?php
    include '../config/connection.php';

    if(isset($_POST['update-smartphone']))
    {
        $id = $_POST['id'];
        $stock = $_POST['stock'];
        $offer = $_POST['offer'];
        $query = "UPDATE `realme-smartphones` SET `OFFER`='$offer',`IN-STOCK`='$stock' WHERE `ID` LIKE '$id'";
        $run = mysqli_query($conn,$query);
        if($run)
        {
            echo "
                <script>
                    alert('New Stock Updated...');
                    alert('New Offer Applied...');
                    window.location.href='update-products.php';
                </script>
            ";
        }
        else
        {
            echo "
                <script>
                    alert('failed to update data');
                    window.location.href='update-products.php';
                </script>
            ";
        }

    }

    if(isset($_POST['update-smarwatch']))
    {
        $id = $_POST['id'];
        $stock = $_POST['stock'];
        $offer = $_POST['offer'];
        $query = "UPDATE `realme-smartwatch` SET `OFFER`='$offer',`IN-STOCK`='$stock' WHERE `ID` LIKE '$id'";
        $run = mysqli_query($conn,$query);
        if($run)
        {
            echo "
                <script>
                    alert('New Stock Updated...');
                    alert('New Offer Applied...');
                    window.location.href='update-products.php';
                </script>
            ";
        }
        else
        {
            echo "
                <script>
                    alert('failed to update data');
                    window.location.href='update-products.php';
                </script>
            ";
        }

    }
?>