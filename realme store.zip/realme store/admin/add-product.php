<?php
    session_start();
    if(isset($_COOKIE["ADMIN"]) || isset($_SESSION["ADMIN"]))
    {
        if(!isset($_SESSION["ADMIN"]))
        {
            $_SESSION["ADMIN"] = $_COOKIE["ADMIN"];
        }
    }
    else
    {
        echo "
            <script>
                window.location.href='login.php';
            </script>
        ";
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/add-product.css">
    <title>Realme - add products</title>
</head>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="../index.php">Home</a>
            <a href="index.php">Dashboard</a>
            <a href="user-orders.php">User Order</a>
            <a href="add-product.php">Add Product</a>
            <a href="remove-products.php">Remove Product</a>
            <a href="update-products.php">Update Product</a>
            <a href="all-products.php">All Products</a>
        </div>  
    </header>
    <div class="container">
        <div class="sub-container">
            <header>
                <span>
                    REALME SMARTPHONE
                </span>
            </header>
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" enctype="multipart/form-data">
                <div class="form-container">
                    <div class="input-data">
                        <input type="text" name="name" id="" placeholder="Name" required autocomplete="off">
                    </div>
                    <div class="input-data">
                        <input type="number" name="price" id="" placeholder="Price" required>
                    </div>
                    <div class="input-data">
                        <input type="number" name="offer" id="" placeholder="Offer" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="ram" id="" placeholder="RAM" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="internal-storage" id="" placeholder="Internal Storage" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="camera" id="" placeholder="Rear Camera | Front Camera" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="processor" id="" placeholder="Processor" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="display" id="" placeholder="Display" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="battery" id="" placeholder="Battery" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="charger" id="" placeholder="Charger" required>
                    </div>
                    <div class="input-data">
                        <input type="number" name="stock" id="" placeholder="In Stock" required>
                    </div>
                    <div class="input-data">
                        <input type="file" name="image" id="" required>
                    </div>
                </div>
                <textarea name="description" id="" cols="30" rows="10" placeholder="Description" required></textarea>
                <div class="input-data">
                    <input type="submit" value="ADD PRODUCT" name="add-smartphone">
                </div>
            </form>
        </div>
        <div class="sub-container">
            <header>
                <span>
                    REALME SMARTWATCH
                </span>
            </header>
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" enctype="multipart/form-data">
                <div class="form-container">
                    <div class="input-data">
                        <input type="text" name="name" id="" placeholder="Name" required autocomplete="off">
                    </div>
                    <div class="input-data">
                        <input type="number" name="price" id="" placeholder="Price" required>
                    </div>
                    <div class="input-data">
                        <input type="number" name="offer" id="" placeholder="Offer" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="display" id="" placeholder="Display" required>
                    </div>
                    <div class="input-data">
                        <input type="text" name="battery" id="" placeholder="Battery" required>
                    </div>
                    <div class="input-data">
                        <input type="number" name="stock" id="" placeholder="In Stock" required>
                    </div>
                    <div class="input-data">
                        <input type="file" name="image" id="" required>
                    </div>
                </div>
                <textarea name="description" id="" cols="30" rows="10" placeholder="Description (Refresh rate | Step Tracker | Heart Rate)" required></textarea>
                <div class="input-data">
                    <input type="submit" value="ADD PRODUCT" name="add-smartwatch">
                </div>
            </form>
        </div>
    </div>
</body>
</html>

<!-- php backend for adding products in database -->

<?php

if($_SERVER["REQUEST_METHOD"]== "POST")
{
    include '../config/connection.php';

    if(isset($_POST["add-smartphone"]))
    {
        $name = $_POST["name"];
        $price = $_POST["price"];
        $offer = $_POST["offer"];
        $ram = $_POST["ram"];
        $internal_storage = $_POST["internal-storage"];
        $camera = $_POST["camera"];
        $processor = $_POST["processor"];
        $display = $_POST["display"];
        $battery = $_POST["battery"];
        $charger = $_POST["charger"];
        $stock = $_POST["stock"];
        $description = $_POST["description"];

        $image = $_FILES['image']['name'];
        $image_temp_loc = $_FILES['image']['tmp_name'];
        $dir_loc = "../img/smartphones/".$image;
        
        $isImageUpload = false;
        if(!file_exists($dir_loc))
        {
            $isImageUpload=move_uploaded_file($image_temp_loc,$dir_loc);
            $query = " INSERT INTO `realme-smartphones`(`ID`, `NAME`, `PRICE`, `OFFER`, `RAM`, `INTERNAL-STORAGE`, `CAMERA`, `PROCESSOR`, `DISPLAY`, `BATTERY`, `CHARGER`, `IN-STOCK`, `IMAGE`, `DESCRIPTION`)VALUES('','$name','$price','$offer','$ram','$internal_storage','$camera','$processor','$display','$battery','$charger','$stock','$image','$description') ";
            $run = mysqli_query($conn,$query);
            if($run && $isImageUpload)
            {
                echo "<script>alert('Product uploaded....');</script>";
            }
            else
            {
                echo "<script>alert('Error..');</script>";
            }
        }
        else
        {
            echo "<script>alert('mobile already exists....');</script>";
        }
    }

    if(isset($_POST["add-smartwatch"]))
    {
        $name = $_POST["name"];
        $price = $_POST["price"];
        $offer = $_POST["offer"];
        $display = $_POST["display"];
        $battery = $_POST["battery"];
        $stock = $_POST["stock"];
        $description = $_POST["description"];

        $image = $_FILES['image']['name'];
        $image_temp_loc = $_FILES['image']['tmp_name'];
        $dir_loc = "../img/watch/".$image;
        
        $isImageUpload = false;
        if(!file_exists($dir_loc))
        {
            $isImageUpload=move_uploaded_file($image_temp_loc,$dir_loc);
            $query = " INSERT INTO `realme-smartwatch`(`ID`, `NAME`, `PRICE`,`DISPLAY`,`OFFER`, `BATTERY`,`IN-STOCK`, `IMAGE`, `DESCRIPTION`)VALUES('','$name','$price','$display','$offer','$battery','$stock','$image','$description') ";
            $run = mysqli_query($conn,$query);
            if($run && $isImageUpload)
            {
                echo "<script>alert('Product uploaded....');</script>";
            }
            else
            {
                echo "<script>alert('Error..');</script>";
            }
        }
        else
        {
            echo "<script>alert('watch already exists....');</script>";
        }
    }
}

?>