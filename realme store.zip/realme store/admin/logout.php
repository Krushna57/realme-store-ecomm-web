<?php
    session_start();
    setcookie("ADMIN","",time()-60);
    unset($_SESSION["ADMIN"]);
    session_unset();
    session_destroy();
    echo "
    <script>
        window.location.href = 'login.php';
    </script>
    ";
    die();
?>
