<?php
    session_start();
    if(isset($_COOKIE["ADMIN"]) || isset($_SESSION["ADMIN"]))
    {
        if(!isset($_SESSION["ADMIN"]))
        {
            $_SESSION["ADMIN"] = $_COOKIE["ADMIN"];
        }
    }
    else
    {
        echo "
            <script>
                window.location.href='login.php';
            </script>
        ";
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - realme</title>
</head>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap");
    body{
        margin: 0;
        padding: 0;
        user-select: none;
        background-color: #f3f3f3;
    }
    header
    {
        display:flex;
        flex-direction:row;
        justify-content:space-between;
    }
    header a 
    {
        box-shadow:5px 0 0 #FFC916;
        text-decoration:none;
        height:20px;
        padding:10px;
        font-family:'ubuntu';
        margin-top: 20px;
        margin-right: 20px;
        border:1px solid  #FFC916;
        font-weight:bolder;
    }
    
    .logo
    {
        text-align: center;
        font-size: 2em;
        font-weight: bolder;
        color: black;
        background: #FFC916;
        padding:3px;
        width: 124px;
        font-family: 'Ubuntu';
        margin-left: 5%;
        margin-top: 20px;
    }
   .container
   {
       width: 80%;
       margin: auto;
       padding: 5%;
       display: flex;
       flex-direction: row;
       flex-wrap:wrap;
       gap:30px;
       place-content: center;
   }
   .box{
       color:black;
       height: 200px;
       width: 250px;
       box-shadow: 0 0 15px gray;
       text-shadow:1px 5px 2px gray;
       display:flex;
       flex-wrap:wrap;
       place-items: center;
       place-content: center;
       font-size: 18pt;
       letter-spacing:3px;
       font-weight: bolder;
       font-family: 'impact';
       cursor: pointer;
       background-image:linear-gradient(110deg,#fdcd3b 60%,#ffed4b 60%);
   }
   .box:hover
   {
       filter:brightness(90%);
   }
</style>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="../index.php">Home</a>
            <a href="logout.php">LogOut</a>
        </div>  
    </header>
    <div class="container">
        <div class="box" onclick="">TOTAL SELL</div>
        <div class="box" onclick="window.location.href='all-products.php'">ALL PRODUCTS</div>
        <div class="box" onclick="window.location.href='add-product.php' ">ADD PRODUCTS</div>
        <div class="box" onclick="window.location.href='update-products.php' ">UPDATE PRODUCTS</div>
        <div class="box" onclick="window.location.href='remove-products.php' ">REMOVE PRODUCTS</div>
        <div class="box" onclick="window.location.href='user-orders.php' ">ORDERS</div>
    </div>
</body>
</html>