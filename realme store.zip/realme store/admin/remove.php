<?php
    include '../config/connection.php';

    if(isset($_POST['remove-smartphone']))
    {
        $id = $_POST['id'];
        $img_name = $_POST["path"];
        $query = "DELETE FROM `realme-smartphones` WHERE `ID` LIKE '$id'";
        $run = mysqli_query($conn,$query);
        
        if($run)
        {
            unlink("../img/smartphones/".$img_name);
            echo "
                <script>
                    alert('Product removed...');
                    window.location.href='remove-products.php';
                </script>
            ";
        }
        else
        {
            echo "
                <script>
                    alert('failed to remove product');
                    window.location.href='remove-products.php';
                </script>
            ";
        }

    }

    if(isset($_POST['remove-smartwatch']))
    {
        $id = $_POST['id'];
        $img_name = $_POST['path'];
        $query = "DELETE FROM `realme-smartwatch` WHERE `ID` LIKE '$id'";
        $run = mysqli_query($conn,$query);
        if($run)
        {
            unlink("../img/watch/".$img_name);
            echo "
                <script>
                    alert('Product removed...');
                    window.location.href='remove-products.php';
                </script>
            ";
        }
        else
        {
            echo "
                <script>
                    alert('failed to remove product');
                    window.location.href='remove-products.php';
                </script>
            ";
        }

    }
?>