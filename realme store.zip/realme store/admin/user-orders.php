<?php
    session_start();
    if(isset($_COOKIE["ADMIN"]) || isset($_SESSION["ADMIN"]))
    {
        if(!isset($_SESSION["ADMIN"]))
        {
            $_SESSION["ADMIN"] = $_COOKIE["ADMIN"];
        }
    }
    else
    {
        echo "
            <script>
                window.location.href='../login.php';
            </script>
        ";
        die();
    }
    include '../config/connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - realme</title>
</head>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap");
    body{
        margin: 0;
        padding: 0;
        user-select: none;
        background-color: #f3f3f3;
    }
    header
    {
        display:flex;
        flex-direction:row;
        justify-content:space-between;
    }
    header a 
    {
        box-shadow:5px 0 0 #FFC916;
        text-decoration:none;
        height:20px;
        padding:10px;
        font-family:'ubuntu';
        margin-top: 20px;
        margin-right: 20px;
        border:1px solid  #FFC916;
        font-weight:bolder;
    }
    
    .logo
    {
        text-align: center;
        font-size: 2em;
        font-weight: bolder;
        color: black;
        background: #FFC916;
        padding:3px;
        width: 124px;
        font-family: 'Ubuntu';
        margin-left: 5%;
        margin-top: 20px;
    }
   .container
   {
       width: 80%;
       margin: auto;
       padding: 5%;
       display: flex;
       flex-direction: row;
       flex-wrap:wrap;
       gap:30px;
       place-content: center;
   }
   .sub-container header
   {
       padding:20px;
       background:#FFC916;
       display:flex;
       place-content:center;
       align-items:center;
       font-family:'ubuntu';
       font-size:20pt;
       font-weight:bolder;
   }
   .row
   {
       margin-top:50px;
       display:flex;
       gap:30px;
   }
   
</style>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="index.php">Dashboard</a>
            <a href="user-orders.php">User Order</a>
            <a href="add-product.php">Add Product</a>
            <a href="remove-products.php">Remove Product</a>
            <a href="update-products.php">Update Product</a>
            <a href="all-products.php">All Products</a>
        </div>  
    </header>
    <div class="container">
        <div class="sub-container">
            <header>
                USERS ORDER
            </header>
            
            <?php
                    $query = "SELECT * FROM `order-history`";
                    $query_run = mysqli_query($conn,$query);
                    while($row = mysqli_fetch_array($query_run))
                    {
                        ?>
                        <div class="row">
                            <div class="col"><?php echo $row["PRODUCT-ID"];?></div>
                            <div class="col"><?php echo $row["PRODUCT-NAME"];?></div>
                            <div class="col"><?php echo $row["PRODUCT-QUANTITY"];?></div>
                            <div class="col"><?php echo $row["PRODUCT-PRICE"];?></div>
                            <div class="col"><?php echo $row["DATE"];?></div>
                            <div class="col"><?php echo $row["USERNAME"];?></div>
                            <form action="" method="post">
                                <div class="col">
                                    <select name="steps" id="">
                                        <option value="Product Packed">Product Packed</option>
                                        <option value="Product Shipped">Product Shipped</option>
                                        <option value="Order Delivered">Order Delivered</option>
                                    </select>
                                </div>
                                <div class="col">
                                    <input type="hidden" name="date" value="<?php echo $row['DATE'];?>">
                                    <input type="hidden" name="user" value="<?php echo $row['USERNAME'];?>">
                                    <?php
                                        if($row['PROCESS'] == "Order Delivered")
                                        {
                                            echo '<input type="submit" value="Update" name="update" disabled>';
                                        }
                                        else
                                        {
                                            echo '<input type="submit" value="Update" name="update">';
                                        }
                                    ?>
                                </div>
                            </form>
                            <div class="col"><font color="green"><?php echo $row["PROCESS"];?></font></div>
                        </div>
                        <?php
                    }
            ?>
        </div>
    </div>
</body>
</html>
<?php
if(isset($_POST['update']))
{
    $step = $_POST['steps'];
    $user = $_POST['user'];
    $date = $_POST['date'];
    $query = "UPDATE `order-history` SET `PROCESS` = '$step' WHERE `USERNAME` LIKE '$user' AND `DATE` LIKE '$date'";
    if(mysqli_query($conn,$query))
    {
        echo"<script>window.location.href='user-orders.php';</script>";
    }
}
?>