<?php
    if(isset($_POST['add-to-cart-btn']))
    {
        if(isset($_COOKIE["USER"]))
        {
            $username = $_COOKIE["USER"];
        }
        else
        {
            echo "
            <script>
            alert('Login as user to continue...');
            window.location.href='login.php';
            </script>
            ";
        }

        include 'config/connection.php';
        $id = $_POST['id'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $stock = $_POST['stock'];
        $price = $price * $quantity;
        if($quantity >$stock)
        {
            echo "
            <script>
            alert('No Stocks Available as your quantity');
            window.location.href='login.php';
            </script>
            ";
        }
        else
        {
            $query = "SELECT * FROM `cart` WHERE `PRODUCT-ID` LIKE '$id' AND `PRODUCT-NAME` LIKE '$name' AND `USERNAME` LIKE '$username'";
            $run = mysqli_query($conn,$query);
            if($run)
            {
                if(mysqli_num_rows($run)>0)
                {
                    echo "
                    <script>
                    alert('Product already added in the cart');
                    window.location.href='index.php';
                    </script>
                    ";
                }
                else
                {
                    $query = " INSERT INTO `cart`(`PRODUCT-ID`, `PRODUCT-NAME`, `PRODUCT-QUANTITY`, `PRODUCT-PRICE`, `USERNAME`) VALUES ('$id','$name','$quantity','$price','$username') ";
                    $run = mysqli_query($conn,$query);
                    if($run)
                    {
                        echo "
                        <script>
                        alert('Product added to cart');
                        window.location.href='mycart.php';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "Error";
                    }
                }
            }
            else
            {
                echo "Error";
            }
        }
        
    }
?>