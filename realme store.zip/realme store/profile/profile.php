<?php
session_start();
if(!isset($_COOKIE['USER']))
{
    header("location:../index.php");
    die();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=0.8">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/profile-style.css">
    <title>realme - Profile</title>
    </head>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap");

        *
        {
            font-family:'ubuntu';
        }
    </style>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="../index.php">HOME</a>
            <a href="../logout.php">LOGOUT</a>
        </div>  
    </header>
    <div class="container">

        <?php
            include '../config/connection.php';

            $username = $_COOKIE['USER'];
            $select_query = " SELECT * FROM `user-register` WHERE `USERNAME` LIKE '$username' ";
            $run = mysqli_query($conn,$select_query);

            if($run->num_rows > 0)
            {
                while($row=mysqli_fetch_assoc($run))
                {
                ?>
                    <table border="0" cellpadding="10" cellspacing="0">
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <form action="" method="post" enctype="multipart/form-data" id="form">
                                    <?php
                                        if($row['IMAGE'] != "")
                                        {
                                            ?>
                                            <img src="pic/<?php echo $row['IMAGE'];?>" height="100" width="100" style="border-radius:50%;" onclick="profile_box.style.display='block'">
                                            <?php
                                        }
                                        else
                                        {
                                            ?>
                                            <img src="../img/icon/user.png" height="100" width="100" style="border-radius:50%;" onclick="profile_box.style.display='block'">
                                            <?php
                                        }
                                    ?>
                                    <center>
                                    <div class="round">
                                        <img src="../img/icon/camera.png" alt="Profile" height="30px">
                                        <input type="hidden" name="id" value="<?php echo $row['ID'];?>">
                                        <input type="hidden" name="name" value="<?php echo $row['IMAGE'];?>">
                                        <input type="file" name="image" id="image" accept=".jpg, .png, .jpeg" required onchange="document.getElementById('form').submit()">
                                    </div>
                                    </center>
                                </form>
                                
                                <div class="profile-box" id="profile_box">
                                    <?php
                                        if($row['IMAGE'] != "")
                                        {
                                            ?>
                                            <img src="pic/<?php echo $row['IMAGE'];?>" height="300px" width="300px" alt="">
                                            <?php
                                        }
                                        else
                                        {
                                            ?>
                                            <img src="../img/icon/user.png" height="300px" width="300px" alt="">
                                            <?php
                                        }
                                    ?>
                                    <div id="minimize" onclick="profile_box.style.display='none'">CLOSE</div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <?php echo $row['USERNAME']; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>NAME</td>
                            <td><?php echo $row['FULLNAME']; ?></td>
                        </tr>
                        <tr>
                            <td>EMAIL</td>
                            <td><?php echo $row['EMAIL']; ?></td>
                        </tr>
                        <tr>
                            <td>MOBILE NUMBER</td>
                            <td><?php echo $row['MOBILENO']; ?></td>
                        </tr>
                        <tr>
                            <td>GENDER</td>
                            <td><?php echo $row['GENDER']; ?></td>
                        </tr>
                        <tr>
                            <td>CITY</td>
                            <td><?php echo $row['CITY']; ?></td>
                        </tr>
                        <tr>
                            <td>STATE</td>
                            <td><?php echo $row['STATE']; ?></td>
                        </tr>
                        <tr>
                            <td>ADDRESS</td>
                            <td><?php echo $row['ADDRESS']; ?></td>
                        </tr>
                    </table>
                <?php
                }
            }
        ?>
    </div>
</body>
</html>

<?php
    if(isset($_FILES['image']['name']))
    {
        $id = $_POST['id'];
        $old_image = $_POST['name'];

        $image = $_FILES['image']['name'];
        $temp_name = $_FILES['image']['tmp_name'];

        $loc = "pic/".$image;
        if(!file_exists($loc))
        {
            $query = "UPDATE `user-register` SET `IMAGE` = '$image' WHERE `ID` LIKE '$id'";
            $run = mysqli_query($conn,$query);
            if($run)
            {
                unlink("pic/".$old_image);
                move_uploaded_file($temp_name,$loc);
                echo "
                <script>
                window.location.href = 'profile.php';
                </script>
                ";
            }
        }
    }


?>