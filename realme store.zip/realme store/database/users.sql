-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2023 at 07:18 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin-login`
--

CREATE TABLE `admin-login` (
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin-login`
--

INSERT INTO `admin-login` (`USERNAME`, `PASSWORD`) VALUES
('krish', '123');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `PRODUCT-ID` int(11) NOT NULL,
  `PRODUCT-NAME` varchar(200) NOT NULL,
  `PRODUCT-QUANTITY` int(11) NOT NULL,
  `PRODUCT-PRICE` int(20) NOT NULL,
  `USERNAME` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `order-history`
--

CREATE TABLE `order-history` (
  `PRODUCT-ID` int(11) NOT NULL,
  `PRODUCT-NAME` varchar(500) NOT NULL,
  `PRODUCT-QUANTITY` int(100) NOT NULL,
  `PRODUCT-PRICE` int(100) NOT NULL,
  `DATE` varchar(100) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PROCESS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `realme-smartphones`
--

CREATE TABLE `realme-smartphones` (
  `ID` int(20) NOT NULL,
  `NAME` varchar(500) NOT NULL,
  `PRICE` int(100) NOT NULL,
  `OFFER` int(20) NOT NULL,
  `RAM` varchar(100) NOT NULL,
  `INTERNAL-STORAGE` varchar(500) NOT NULL,
  `CAMERA` varchar(500) NOT NULL,
  `PROCESSOR` varchar(500) NOT NULL,
  `DISPLAY` varchar(500) NOT NULL,
  `BATTERY` varchar(500) NOT NULL,
  `CHARGER` varchar(500) NOT NULL,
  `IN-STOCK` int(100) NOT NULL,
  `IMAGE` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `realme-smartphones`
--

INSERT INTO `realme-smartphones` (`ID`, `NAME`, `PRICE`, `OFFER`, `RAM`, `INTERNAL-STORAGE`, `CAMERA`, `PROCESSOR`, `DISPLAY`, `BATTERY`, `CHARGER`, `IN-STOCK`, `IMAGE`, `DESCRIPTION`) VALUES
(7, 'REALME 9 PRO', 21999, 10, '6 GB RAM ', '128 GB ROM | Expandable Upto 256 GB', '64MP + 8MP + 2MP | 16MP Front Camera', 'Qualcomm Snapdragon 695 Processor', '16.76 cm (6.6 inch) Full HD+ Display', '5000 mAh Li-ion Battery', '33W Draft Charger', 7, 'realme 9 pro.png', 'NA'),
(9, 'realme 9 5G SE', 22999, 14, '8 GB RAM', '128 GB ROM | Expandable Upto 1 TB', '48MP + 2MP + 2MP | 16MP Front Camera', 'Qualcomm Snapdragon 778G Processor', '16.76 cm (6.6 inch) Full HD+ Display', '5000 mAh Lithium Polymer Battery', '30W', 200, 'realme 9 5g speed edition.png', 'The realme 9 5G SE, sporting a plethora of impeccable features, is a treat to the Tech-geeks. Driven by the Snapdragon 778G 5G processor and a 6 nm architecture, this phone delivers an immaculate performance. With the 144 Hz, Adaptive Gaming Screen and a 6-level variable refresh rate the smoothness in its operation makes this phone irresistible. The realme 9 5G SE boasts a robust 5000 mAh battery and it also comes with 30 W Rapid Charging technology that enhances the operational efficiency of this phone. The unique Starlight Texture incorporated in this phone enhances the durability of the device. The 48 MP rear camera, powered by AI, equipped in this smartphone helps capture beautiful images with enthralling clarity. Sporting a huge RAM and internal storage of up to 128 GB, this phone is ideal for both personal and professional usage.'),
(10, 'realme 9 5G ', 15999, 15, '4 GB RAM', '64 GB ROM | Expandable Upto 1 TB', '48MP + 2MP + 2MP | 16MP Front Camera', 'Mediatek Dimensity 810 Processor', '16.51 cm (6.5 inch) Full HD+ Display', '5000 mAh Lithium Polymer Battery', '30W', 250, 'realme 9 5g.png', 'With a 2.4 GHz processor and an innovative 6 nm architecture, the realme 9 5G is all set to be your reliable and efficient workmate. The 16.51 cm (6.5) LCD display along with the refresh rate of 90 Hz enhances the visual and operational experience. The 16 MP front camera is sure to quench your selfie thirst by creating beautiful imagery. The Street Photography Mode allows you to capture images even in low light conditions. This phone offers 4 GB of RAM and 64 GB of internal storage making it suitable for extensive usage.'),
(11, 'realme 9 Pro+ 5G', 26999, 10, '8 GB RAM', '128 GB ROM | Expandable Upto 1 TB', '50MP + 8MP + 2MP | 16MP Front Camera', 'Mediatek Dimensity 920 Processor', '16.26 cm (6.4 inch) Full HD+ AMOLED Display', '4500 mAh Li-ion Battery', '30W', 150, 'realme 9 pro+.png', 'in the box: Handset, Adapter (10V/6.5A), USB Cable, Important Info Booklet with Warranty Card, Quick Guide, Sim Card Tool, Screen Protect Film, TPU Case'),
(12, 'realme 9i (NL Power)', 14999, 11, '4 GB RAM', '128 GB ROM | Expandable Upto 1 TB', '50MP + 2MP + 2MP | 16MP Front Camera', 'Qualcomm Snapdragon 680 (SM6225) Processor', '16.76 cm (6.6 inch) Full HD+ Display', '5000 mAh Lithium ion Battery', '30W', 200, 'realme 9i next-level power.png', 'In The Box:\r\nHandset, Adapter, USB Cable, Important Info Booklet with Warranty Card, Quick Guide, SIM Card Tool, Screen Protect Film, Case'),
(13, 'realme 9i ', 14999, 11, '4 GB RAM', '128 GB ROM | Expandable Upto 1 TB', '50MP + 2MP + 2MP | 16MP Front Camera', 'Qualcomm Snapdragon 680 (SM6225) Processor', '16.76 cm (6.6 inch) Full HD+ Display', '5000 mAh Lithium ion Battery', '30W', 300, 'realme 9i.png', 'In the box: \r\nHandset, Adapter, USB Cable, Important Info Booklet with Warranty Card, Quick Guide, SIM Card Tool, Screen Protect Film, Case'),
(14, 'realme C25Y', 12000, 10, '4 GB RAM', '64 GB ROM | Expandable Upto 256GB', '48MP + 2MP + 2MP | 8MP Front Camera', 'Unisoc T610 Octa Core Processor', '16.51 cm (6.5 inch) HD+ Display', '5000 mAh Battery', '15W', 0, 'realme c25y.png', 'NA'),
(15, 'realme C35', 13999, 14, '4 GB RAM', '64 GB ROM | Expandable Upto 1 TB', '50MP + 2MP + 0.3MP | 8MP Front Camera', 'Unisoc Tiger T616 Processor', '16.76 cm (6.6 inch) Full HD+ Display', '5000 mAh Lithium Polymer Battery', '15W', 300, 'realme c35.png', 'Watch videos, TV shows, and play games for hours with the realme C35 smartphone. This mobile phone comes equipped with a powerful 5000 mAh battery so that you can indulge in long hours of entertainment. Also, this mobile phone has a 16.76 cm (6.6) display for mesmerizing visuals. Moreover, this phone is powered by an efficient 12 nm octa-core processor to offer seamless gaming and easy multi-tasking.\r\n'),
(16, 'realme Narzo 50', 17999, 19, '6 GB RAM', '128 GB ROM | Expandable Upto 256 GB', '50MP + 2MP + 2MP | 16MP Front Camera', 'Mediatek Helio G96 Processor', '16.76 cm (6.6 inch) Full HD+ Display', '5000 mAh Lithium Polymer Battery', '30W', 300, 'realme narzo 50.png', 'NA'),
(17, 'realme Narzo 50A', 12999, 11, '4 GB RAM', '64 GB ROM | Expandable Upto 256GB', '50MP + 2MP + 2MP | 8MP Front Camera', 'MediaTek Helio G85 Processor', '16.51 cm (6.5 inch) HD+ Display', '6000 mAh Battery', '18W', 300, 'realme narzo 50a.png', 'Equipped with a Helio G85 Gaming Processor, the realme Narzo 50A is a high-speed smartphone that lets you play intense games and binge-watch favourite shows. This smartphone features a 6000 mAh Battery and 18W Quick Charge for uninterrupted performance, and a 50 MP AI Triple Camera to click beautiful photos.');

-- --------------------------------------------------------

--
-- Table structure for table `realme-smartwatch`
--

CREATE TABLE `realme-smartwatch` (
  `ID` int(20) NOT NULL,
  `NAME` varchar(500) NOT NULL,
  `PRICE` int(20) NOT NULL,
  `DISPLAY` varchar(500) NOT NULL,
  `OFFER` int(13) NOT NULL,
  `BATTERY` varchar(500) NOT NULL,
  `IN-STOCK` int(100) NOT NULL,
  `IMAGE` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(3000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `realme-smartwatch`
--

INSERT INTO `realme-smartwatch` (`ID`, `NAME`, `PRICE`, `DISPLAY`, `OFFER`, `BATTERY`, `IN-STOCK`, `IMAGE`, `DESCRIPTION`) VALUES
(2, 'realme Watch 2', 3499, '3.5cm(1.4) large color touchscreen ', 14, '12 - day', 200, 'realme watch 2.png', 'Smart AIoT Control | Sport modes | 12 day battery life | 3.5 cm large display | blood Oxygen  And Heart Rate Monitor'),
(5, 'realme Watch 2 Pro', 4999, '4.4 cm large color display', 10, '14-day long-lasting battery life', 5, 'realme watch 2pro.png', 'Smart AIoT Control | Sport modes | 12 day battery life | 3.5 cm large display | blood Oxygen  And Heart Rate Monitor');

-- --------------------------------------------------------

--
-- Table structure for table `user-register`
--

CREATE TABLE `user-register` (
  `ID` int(11) NOT NULL,
  `FULLNAME` varchar(100) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `MOBILENO` varchar(13) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `CITY` varchar(100) NOT NULL,
  `STATE` varchar(100) NOT NULL,
  `ADDRESS` varchar(500) NOT NULL,
  `GENDER` varchar(20) NOT NULL,
  `IMAGE` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `realme-smartphones`
--
ALTER TABLE `realme-smartphones`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `realme-smartwatch`
--
ALTER TABLE `realme-smartwatch`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user-register`
--
ALTER TABLE `user-register`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `realme-smartphones`
--
ALTER TABLE `realme-smartphones`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `realme-smartwatch`
--
ALTER TABLE `realme-smartwatch`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user-register`
--
ALTER TABLE `user-register`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
