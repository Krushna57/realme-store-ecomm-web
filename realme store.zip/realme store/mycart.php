<?php
    session_start();
    if(isset($_COOKIE["ADMIN"]))
    {
        echo"
        <script>
            alert('login with user...');
            window.location.href = 'admin/index.php';
        </script>
        ";
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - realme</title>
</head>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap");
    body{
        margin: 0;
        padding: 0;
        user-select: none;
        background-color: #f3f3f3;
    }
    header
    {
        display:flex;
        flex-direction:row;
        justify-content:space-between;
    }
    header a 
    {
        box-shadow:5px 0 0 #FFC916;
        text-decoration:none;
        height:20px;
        padding:10px;
        font-family:'ubuntu';
        margin-top: 20px;
        margin-right: 20px;
        border:1px solid  #FFC916;
        font-weight:bolder;
    }
    
    .logo
    {
        text-align: center;
        font-size: 2em;
        font-weight: bolder;
        color: black;
        background: #FFC916;
        padding:3px;
        width: 124px;
        font-family: 'Ubuntu';
        margin-left: 5%;
        margin-top: 20px;
    }
   .container
   {
       width: 90%;
       margin: auto;
       padding: 5%;
       display: flex;
       flex-direction: row;
       flex-wrap:wrap;
       gap:30px;
       place-content:center;
   }
   .inner-container
   {
       width:60%;
       box-shadow:0 0 7px gray;
   }
   .inner-container header
   {
       height:30px;
       background:#FFC916;
       display:flex;
       place-content:center;
       align-items:center;
       font-family:'ubuntu';
       font-size:20pt;
       font-weight:bolder;
   }
   .row 
   {
       width:100%;
       padding:5px;
       display:flex;
       flex-direction:row;
       gap:10px;
   }
   .col{
        font-family:'ubuntu';
   }
   .box{
       padding:10px;
       font-family:'ubuntu';
       width:400px;
       box-shadow:0 0 7px gray;
       height:320px;
   }
   .box p{
        display:flex;
        place-content:space-between;
   }
   .box input[type=button]
   {
       padding:10px;
       border:none;
       background:#FFC916;
       cursor: pointer;
   }
   #remove
   {
       padding:7px;
       border:none;
       background:red;
       cursor: pointer;
   }
   section{
       position:relative;
       top:40%;
       left:70%;
       transform:translate(-50%);
       font-family:'ubuntu';
   }
</style>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="index.php">Home</a>
        </div>  
    </header>
    <div class="container">
       <div class="inner-container">
            <header>
                MYCART
            </header>
            <?php
                if(isset($_COOKIE['USER']))
                {
                    $username = $_COOKIE['USER'];
                    $total_price = 0;
                    $total_save = 0;
                    include 'config/connection.php';

                    $query = "SELECT * FROM `cart` WHERE `USERNAME` LIKE '$username'";
                    $run = mysqli_query($conn,$query);

                    if($run)
                    {
                        $row_count = mysqli_num_rows($run);
                        if($row_count>0)
                        {
                            while($row = mysqli_fetch_array($run))
                            {
                                $id = $row['PRODUCT-ID'];
                                $name = $row['PRODUCT-NAME'];
                                $quantity = $row['PRODUCT-QUANTITY'];

                                $query = "SELECT * FROM `realme-smartphones` WHERE `ID` LIKE '$id' AND `NAME` LIKE '$name'";
                                $run1 = mysqli_query($conn,$query);
                                if($run1)
                                {
                                    if(mysqli_num_rows($run1)>0)
                                    {
                                        $row1 = mysqli_fetch_array($run1);
                                        $offer = $row1["OFFER"];
                                        $original_price = $row1["PRICE"];
                                        $saved_money = round($offer * $original_price / 100);
                                        $price = $original_price - $saved_money;

                                        $total_save = $total_save + $saved_money;
                                        $total_price = $total_price + $price*$quantity;
                                        ?>
                                            <div class="row">
                                                <div class="col">
                                                    <img src="img/smartphones/<?php echo $row1['IMAGE']?>" alt="" height="70">
                                                </div>
                                                <div class="col">
                                                    <?php echo "<strong>".$row1['NAME']." (".$row1['RAM'].", ".$row1['INTERNAL-STORAGE']." )</strong>";?> <br>                                                    
                                                    <?php echo "PRICE ₹".$price." <small><s>$original_price</s> $offer% off</small><br> Save $saved_money";?><br>                                                    
                                                    <?php echo "<small>".$row1['DISPLAY'];?> <br>                                                    
                                                    <?php echo $row1['CAMERA'];?> <br>                                                    
                                                    <?php echo $row1['PROCESSOR']."</small>";?> <br>
                                                    Item Quantity : <?php echo $quantity;?><br><br>
                                                    <form action="remove-from-cart.php" method="post">
                                                        <input type="hidden" name="id" value="<?php echo $row1['ID'];?>">
                                                        <input type="hidden" name="name" value="<?php echo $row1['NAME'];?>">
                                                        <input type="submit" value="REMOVE" name="remove" id="remove">
                                                    </form>                                                 
                                                </div>
                                            </div>
                                            <hr>
                                        <?php
                                    }
                                    else
                                    {
                                        $query = "SELECT * FROM `realme-smartwatch` WHERE `ID` LIKE '$id' AND `NAME` LIKE '$name'";
                                        $run2 = mysqli_query($conn,$query);
                                        if($run2)
                                        {
                                            if(mysqli_num_rows($run2)>0)
                                            {
                                                $row2 = mysqli_fetch_array($run2);
                                                $offer = $row2["OFFER"];
                                                $original_price = $row2["PRICE"];
                                                $saved_money = round($offer * $original_price / 100);
                                                $price = $original_price - $saved_money;

                                                $total_price = $total_price + $price*$quantity;
                                                $total_save = $total_save + $saved_money;
                                                ?>
                                                    <div class="row">
                                                        <div class="col">
                                                            <img src="img/watch/<?php echo $row2['IMAGE']?>" alt="" height="70">
                                                        </div>
                                                        <div class="col">
                                                            <?php echo "<strong>".$row2['NAME']."</strong>";?> <br>
                                                            <?php echo "PRICE ₹".$price." <small><s>$original_price</s> $offer% off</small><br> Save $saved_money";?><br>                                                                                                        
                                                            <?php echo "<small>".$row2['DISPLAY'];?> <br>                                                    
                                                            <?php echo $row2['BATTERY']."</small>";?>    <br>
                                                            Items Quantity : <?php echo $quantity;?> <br>
                                                            <br>
                                                            
                                                            <form action="remove-from-cart.php" method="post">
                                                                <input type="hidden" name="id" value="<?php echo $row2['ID'];?>">
                                                                <input type="hidden" name="name" value="<?php echo $row2['NAME'];?>">
                                                                <input type="submit" value="REMOVE" name="remove" id="remove">
                                                            </form>                                              
                                                        </div>
                                                    </div>
                                                    <hr>
                                                <?php
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            ?>
                                <section>
                                    Empty cart... ? <a href="index.php">Continue Shoping</a> 
                                </section>
                            <?php
                        }
                    }
                    $_SESSION['TOTAL_PRICE'] = $total_price;
                }
                else
                {
                    echo"
                    <script>
                        alert('Please login to continue');
                        window.location.href = 'login.php';
                    </script>
                    ";
                    die();
                }
            ?>
       </div>
       <div class="box">
            <p><b>PRICE DETAILS</b></p><hr>
            <P>
                <span>ITEMS PRICE</span>
                <span><?php echo "₹".$total_price; ?></span>
            </P>
            <p>
                <span>Delivery Charges</span>
                <span><font color="green">FREE</font></span>
            </p>
            <p>
                <span>Secured Packaging Fee</span>
                <span><font color="green">NA</font></span>
            </p>
            <hr>
            <p>
                <span><b>TOTAL AMOUNT</b></span>
                <span><b><?php echo "₹".$total_price; ?></b></span>
            </p>
            <hr>
            <p>
                <span>
                    <font color="green"><?php echo "<big><b>You will save ₹".$total_save." on this order.</b></big>";?></font>
                </span>
            </p>
            <?php
                if($row_count>0)
                {
                    ?>
                    <input type="button" value="PLACE ORDER" onclick="window.location.href='payment/payment-process.php'">
                    <?php
                }
                else
                {
                    ?>
                    <input type="button" value="CONTINUE SHOPING" onclick="window.location.href='index.php'">
                    <?php
                }
            ?>
       </div>
    </div>
</body>
</html>

