<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Order Receipt</title>
</head>
<style>
    @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap");
    body
    {
        margin: 0;
        padding: 0;
        user-select: none;
        background-color: #f3f3f3;
    }
     header
    {
        margin-top: 20px;
        /* background-color: black; */
        padding: 30px;
        display: flex;
        flex-direction: row;
    }
    .logo
    {
        font-size: 1.5em;
        font-weight: bolder;
        color: black;
        background: #FFC916;
        width: 100px;
        font-family: 'Ubuntu';
        text-align: center;
        height: 30px;
        cursor: pointer;
    }
    .container{
        display:flex;
        place-content:center;
        gap:50px;
    }
    .box
    {
        width:450px;
        height:300px;
        border:1px solid;
        padding:20px;
        font-family:verdana;
        font-size:13px;
    }
    .box p{
        font-style:normal;
    }
    table{
        margin:auto;
        width:80%;
        text-align:left;
        font-family:verdana;
    }

</style>
<body onload="window.print()">
    <header>
        <div class="logo">realme</div>
    </header>
    <div class="container">
        <div class="box">
            <h2>Company Details</h2>
            <address>
                <p><b>Legal Name:</b> Realme Mobile Telecommunications (India) Private Limited</p>
                <p><b>Headquarter Address:</b> 3rd Floor, Tower B, Building Number 8, DLF Cyber City, Gurugram-122002, Haryana, India</p>
                <p>
                <b>Customer Care:</b><br>
                <b>Phone Number:</b> 18001022777 <br>
                <b>Email:</b> service@realme.com <br>
                <b>Address:</b> Realme Mobile Telecommunications (India) Private Limited, 3rd Floor, Tower B, Building Number 8, DLF Cyber City, Gurugram-122002, Haryana, India
                </p>
            </address>
        </div>
        <div class="box">
            <h2>Your Details</h2>
            <address>
                <?php
                    include '../config/connection.php';
                    $total_price = $_SESSION['TOTAL_PRICE'];

                    $username = $_COOKIE['USER'];
                    $select_query = " SELECT * FROM `user-register` WHERE `USERNAME` LIKE '$username' ";
                    $run = mysqli_query($conn,$select_query);
                    $row = mysqli_fetch_array($run);
                    if($run)
                    {
                        ?>
                        <p> <b>Name :</b><?php echo $row['FULLNAME'];?></p>
                        <p> <b>Email :</b><?php echo $row['EMAIL'];?></p>
                        <p> <b>Mobile Number :</b><?php echo $row['MOBILENO'];?></p>
                        <p> <b>Gender :</b><?php echo $row['GENDER'];?></p>
                        <p> <b>Address :</b><?php echo $row['ADDRESS'];?></p>
                        <p> <b>Cty :</b><?php echo $row['CITY'];?></p>
                        <p> <b>State :</b><?php echo $row['STATE'];?></p>
                        <?php
                    }
                   
                ?>
            </address>
        </div>
    </div>
    <p>
       <h2>
           <center>
               Your Order...
           </center>
       </h2>
    </p>
    <table cellpadding="7" cellspacing="0" border>
            <tr>
                <th>SR. NO.</th>
                <th>ID</th>
                <th>NAME</th>
                <th>QUANTITY</th>
                <th>PRICE</th>
            </tr>
            <?php
                $query = "SELECT * FROM `cart` WHERE `USERNAME` LIKE '$username'";
                $run = mysqli_query($conn,$query);

                if($run)
                {
                    $count = 0;
                    $row_count = mysqli_num_rows($run);
                    if($row_count>0)
                    {
                        while($row = mysqli_fetch_array($run))
                        {
                            $count = $count +1;
                            ?>
                            <tr>
                                <td><?php echo $count;?></td>
                                <td><?php echo $row['PRODUCT-ID'];?></td>
                                <td><?php echo $row['PRODUCT-NAME'];?></td>
                                <td><?php echo $row['PRODUCT-QUANTITY'];?></td>
                                <td><?php echo $row['PRODUCT-PRICE'];?></td>
                            </tr>
                            <?php
                        }
                        ?>
                        <tr>
                            <th colspan="5">TOTAL :<?php echo "₹".$total_price;?></th>
                        </tr>
                        <tr>
                            <th colspan="5">
                                Date : <script>document.write(Date());</script>
                            </th>
                        </tr>
                        <?php
                    }
                }
            ?>
    </table>
<br>
<br>
<center>
    <input type="button" value="Print" onclick="window.print()">
</center>
<br><br>

<center>
© 2018-2022 realme. All Rights Reserved.
</center>


</body>
</html>