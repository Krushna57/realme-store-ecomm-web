<?php
  session_start();
  if(!isset($_COOKIE['USER']))
  {
      echo "
          <script>
              alert('please login to continue...');
              window.location.href = '../login.php';
          </script>
          ";
      die();
  }
include '../config/connection.php';

 $total_price = $_SESSION['TOTAL_PRICE'];

 $username = $_COOKIE['USER'];
 $select_query = " SELECT * FROM `user-register` WHERE `USERNAME` LIKE '$username' ";
 $run = mysqli_query($conn,$select_query);
 $row = mysqli_fetch_array($run);
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; 
  display: flex;
  -ms-flex-wrap: wrap; 
  flex-wrap: wrap;
  margin: 0 -16px;
}


.col-50 {
  -ms-flex: 50%; 
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; 
  flex: 75%;
}

.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
  width: 600px;
  margin: auto;
}

input[type=text],input[type=email] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #FFC916;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}


@media (max-width: 600px) {
  .row {
    flex-direction: column-reverse;
  }
  .container
  {
      width: auto;
  }
}
</style>
</head>
<body>

<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="pay.php" method="POST">
      
        <div class="row">
          <div class="col-50" id="col_1">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="fullname" value="<?php echo $row['FULLNAME'];?>" readonly>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="email" id="email" name="email"  value="<?php echo $row['EMAIL'];?>" readonly>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address"  value="<?php echo $row['ADDRESS'];?>" readonly>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" value="<?php echo $row['CITY'];?>" readonly>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" value="<?php echo $row['STATE'];?>" readonly>
              </div>
            </div>
          </div>

          <div class="col-50" style="display: none;" id="col_2">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" required>
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" pattern="\d+$" minlength="16" maxlength="16" required>
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" pattern="\d+$" minlength="2" maxlength="2" max="12" required>
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" pattern="\d+$" minlength="4" maxlength="4"
                 onblur="
                    var d = new Date();
                    var y = d.getFullYear();
                    if(this.value < y)
                    {
                        this.value=null;
                    }
                 "
                  required>
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" pattern="\d+$" minlength="3" maxlength="3" required>
              </div>
            </div>
          </div>
          
        </div>
        <input type="button" value="Continue to checkout" id="btn" class="btn" style="background: #FFC916;"
        onclick="
          col_2.style.display='block';
          col_1.style.display='none';
          this.value='Pay <?php if($total_price >0){echo $total_price;}?>';
          this.type='submit';
          this.name='submit';
        "
        >
      </form>
    </div>
  </div>
</div>

</body>
</html>
