<!DOCTYPE html>
<html lang="en">
<body>
<?php
session_start();
if(!isset($_COOKIE['USER']))
{
    echo "
    <script>
        alert('please login to continue...');
        window.location.href = 'login.php';
    </script>
    ";
    die();    
}

include '../config/connection.php';
$username = $_COOKIE['USER'];

$query = "SELECT * FROM `user-register` WHERE `USERNAME` LIKE '$username'";
$run=mysqli_query($conn,$query);
if($run)
{
    $row=mysqli_fetch_array($run);
}
$to = "krushnasahane7@gmail.com";
$subject = "REALME INDIA - (DARE TO LEAP)";
$header= "MIME-version:1.0"."\r\n";
$header .= "Content-type:text/html;charset=UTF-8"."\r\n";


$message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body{
            margin: 0%;
            padding: 0%;
        }
        header{
            padding:10px;
            background: #FFC916;
            font-size: 18pt;
            font-weight: bold;
            display: flex;
            flex-direction: column;
            align-items: center;
            place-content: center;
        }
        .container
        {
            padding: 30px;
        }
        .container p
        {
            text-align: justify;
            font-size: 13pt;
        }
    </style>
<body>
    <header>
        Realme India - (Dare To Leap)
    </header>
    <div class="container">
        <p>
           Dear realme user, <br>
           You have successfully ordered the Realme Products<br>
           Your Order Summery...
        </p>
        <table cellpadding="10" border="1" cellspacing="0">
            <tr>
                <th>SR. NO</th>
                <th>NAME</th>
                <th>QUANTITY</th>
                <th>PRICE</th> 
            </tr>
            ';

$data="";
$count = 0;
$total_price = 0;
$product_name ="" ;
$product_quantity= "";
$product_price ="";



$select_query = " SELECT * FROM `cart` WHERE `USERNAME` LIKE '$username' ";
$run = mysqli_query($conn,$select_query);

    if($run)
    {
        while($row = mysqli_fetch_assoc($run))
        {
            $count = $count + 1;
            $total_price = $total_price + $row["PRODUCT-PRICE"];
            $product_name = $row['PRODUCT-NAME'];
            $product_quantity = $row['PRODUCT-QUANTITY'];
            $product_price = $row['PRODUCT-PRICE'];

            $data.="\n"."
            <tr>
                <td>$count</td>
                <td>$product_name</td>
                <td>$product_quantity</td>
                <td>$product_price </td>
            </tr>";
            
        }
    }
    
    $data.="
    <tr>
        <td>Total </td>
        <td colspan='3'>$total_price</td>
    </tr>
</table>
</div>
</body>
</html>";

$message.="$data"."Thank You - Team Realme India";

$result = mail($to,$subject,$message,$header);

 if($result)
 {
    $select_query = " SELECT * FROM `cart` WHERE `USERNAME` LIKE '$username' ";
    $run1 = mysqli_query($conn,$select_query);
    date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
    $date = date('d-m-Y H:i:s');
    
        if($run)
        {
            while($row = mysqli_fetch_array($run1))
            {
                $id = $row['PRODUCT-ID'];
                $name = $row['PRODUCT-NAME'];
                $quantity = $row['PRODUCT-QUANTITY'];
                $price = $row['PRODUCT-PRICE'];                
                $username = $row['USERNAME'];
                $query = "INSERT INTO `order-history`(`PRODUCT-ID`, `PRODUCT-NAME`, `PRODUCT-QUANTITY`, `PRODUCT-PRICE`, `DATE`, `USERNAME`, `PROCESS`)VALUES ('$id','$name','$quantity','$price','$date','$username','Ordered Successfully...')";
                $query_run = mysqli_query($conn,$query);
            }
            
        }
    echo "
    <img src='payment-success.gif' height='500' style='position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);' id='img_payment'>
    <p style='font-size:22pt;font-weight:bold; position:absolute;top:70%;left:50%;transform:translate(-50%);' id='success_payment_text'>Payment Successfull</p>
    <script>
        setTimeout(hide,3000);
        function hide()
        {
            window.location.href='order-receipt.php';
        }
    </script>
    ";
 }
 else
 {
    echo "
    <img src='Payment-Failed.png' height='200' style='position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);' id='img_payment'>
    <p style='font-size:22pt;font-weight:bold; position:absolute;top:60%;left:50%;transform:translate(-50%);' id='failed_payment_text'>Payment Failed</p>
    <script>
        setTimeout(hide,3000);
        function hide()
        {
            window.location.href='../mycart.php';
        }
    </script>
    ";
 }

?>

</body>
</html>