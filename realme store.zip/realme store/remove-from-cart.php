<?php
$username = $_COOKIE['USER'];

if(isset($_POST['remove']))
{
    include 'config/connection.php';
    $id = $_POST['id'];
    $name = $_POST['name'];
    $query = "DELETE FROM `cart` WHERE `PRODUCT-ID` LIKE '$id' AND `PRODUCT-NAME` LIKE '$name' AND `USERNAME` LIKE '$username'";
    $run=mysqli_query($conn,$query);
    if($run)
    {
        echo"
        <script>
            alert('Product removed from cart...');
            window.location.href = 'mycart.php';
        </script>
        ";
    }
    else
    {
        echo "Error";
    }
    
}



?>