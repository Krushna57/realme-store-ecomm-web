<?php 
session_start();
if(isset($_SESSION["USER"]) || isset($_COOKIE["USER"]))
{
    echo "<script>window.location.href='index.php';</script>";
    die();
}
if(isset($_COOKIE["ADMIN"]) || isset($_SESSION['ADMIN']))
{
    echo "<script>window.location.href='admin/index.php';</script>";
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="img/icon/icon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/register-style.css">
    <title>register</title>
</head>
<style>
    header
{
  display:flex;
  flex-direction:row;
  justify-content:space-between;
}
.logo
{
    margin-top: 20px;
    margin-left: 20px;
    font-size: 1.5em;
    font-weight: bolder;
    color: black;
    background: #FFC916;
    width: 100px;
    font-family: 'Ubuntu';
    text-align: center;
    height: 30px;
    cursor: pointer;
}
header .nav a 
{
    box-shadow:5px 0 0 #FFC916;
    text-decoration:none;
    height:20px;
    padding:10px;
    font-family:'ubuntu';
    margin-right: 20px;
    border:1px solid  #FFC916;
    font-weight:bolder;
}


</style>
<body>
    <header>
        <div class="logo">realme</div>
        <div class="nav" style="margin-top:30px;">
            <a href="index.php">Home</a>
            <a href="login.php">Login</a>
            <a href="admin/login.php">Admin Login</a>
        </div>  
    </header>
    <div class="container">
        <div class="login-text">Register</div>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <div class="login-form">
                <div class="input-box">
                    <input type="text" name="fullname" placeholder="Fullname" required>
                </div>
                <div class="input-box">
                    <input type="text" name="username" placeholder="Username" required>
                </div>
                <div class="input-box">
                    <input type="email" name="email" id="" placeholder="Email" required>
                </div>
                <div class="input-box">
                    <input type="text" name="mob" placeholder="Phone Number" required>
                </div>
                <div class="input-box">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <div class="input-box">
                    <input type="text" name="city" id="" placeholder="City" required>
                </div>
                <div class="input-box">
                    <input type="text" name="state" id="" placeholder="State" required>
                </div>
                <div class="input-box">
                    <textarea name="address" id="" cols="30" rows="10" placeholder="Address" required></textarea>
                </div>
                <div class="input-box">
                   <input type="radio" name="gender" value="male" id="" required> Male
                   <input type="radio" name="gender" value="female" id=""> Female
                   <input type="radio" name="gender" value="other" id=""> Other
                </div>
            </div>
            <div class="submit-btn">
               <center>
                <input type="submit" value="Register" name="register">
                <p>Already have an account? <a href="login.php">Login</a></p>
               </center>
            </div>
        </form>   
    </div>
</body>
</html>

<?php
include 'config/connection.php';
if(isset($_POST['register']))
{
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $username = trim($username); 
    $email = $_POST['email'];
    $mobileno = $_POST['mob'];
    $password = $_POST['password']; 
    $city = $_POST['city'];
    $state = $_POST['state'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];

    $select_query="SELECT * FROM `user-register` WHERE `USERNAME` LIKE '$username'";
    $run = mysqli_query($conn,$select_query);

    if($run->num_rows > 0)
    {
        echo "
        <script>
            alert('Username Already exists...');
        </script>
        ";
    }
    else
    {
        $insert_query = " INSERT INTO `user-register`(`ID`, `FULLNAME`, `USERNAME`, `EMAIL`, `MOBILENO`, `PASSWORD`, `CITY`, `STATE`, `ADDRESS`, `GENDER`) VALUES ('','$fullname','$username','$email','$mobileno','$password','$city','$state','$address','$gender') ";
        $run = mysqli_query($conn,$insert_query);
        if($run) 
        {
            echo "
              <script>window.location.href='login.php';</script>
            ";
            die();
        }
    }
}
?>