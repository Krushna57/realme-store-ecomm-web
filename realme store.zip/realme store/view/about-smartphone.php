<?php
session_start();
if(isset($_POST['view']))
{
    $id = $_POST['id'];
}
else
{
    echo "<script>window.location.href='../index.php';</script>";
    die();
}

include '../config/connection.php';
$query = "SELECT * FROM `realme-smartphones` WHERE `ID` LIKE '$id'";
$run = mysqli_query($conn,$query);

if($run)
{
    if(mysqli_num_rows($run) > 0)
    {
        $row = mysqli_fetch_array($run);
        $stock = $row["IN-STOCK"];
        $offer = $row["OFFER"];
        $original_price = $row["PRICE"];
        $saved_money = round($offer * $original_price / 100);
        $price = $original_price - $saved_money;
    }
    else
    {
        echo "<script>
            alert('No product Available... Please refresh the page to see updated content');
            window.location.href='../index.php';
        </script>";
        die();
    }
}
else
{
    echo "Server error";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="../img/icon/icon.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/about-smartphone.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>realme - view product</title>
</head>
<body>
    <header>
        <div class="logo">realme</div>
        <a href="../index.php">Home</a>
    </header>
    <div class="container">
        <div class="inner-container">
            <center>
                <img src="../img/smartphones/<?php echo $row['IMAGE'];?>" alt="image">
            </center>
            <form action="../add-to-cart.php" method="post">
                <div class="action">
                    <input type="number" min="1" value="1" max="10" name="quantity" id="">
                    <?php
                        if($stock > 0)
                        {
                            ?>
                            <center>
                                <input type="hidden" name="id" value="<?php echo $row['ID'];?>">
                                <input type="hidden" name="name" value="<?php echo $row['NAME'];?>">
                                <input type="hidden" name="stock" value="<?php echo $stock;?>">
                                <input type="hidden" name="price" value="<?php echo $price;?>">
                                <input type="submit" id="btn-1" name="add-to-cart-btn" value="ADD TO CART">
                                <!-- <input type="submit" id="btn-2" name="buy-now-btn" value="BUY NOW"> -->
                            </center>
                            <?php
                        }
                        else
                        {
                            ?>
                            <center>
                                <input type="button" id="btn-1" value="ADD TO CART" disabled>
                                <!-- <input type="button" id="btn-2" value="BUY NOW" disabled> -->
                            </center>
                            <?php
                        }
                    ?>
                </div>
            </form>
        </div>
        <div class="inner-container">
            <p><strong><?php echo $row['NAME']." ( ".$row['RAM']." )";?></strong></p>
            <P>
                <b><?php echo "₹".$price;?></b>
                <s style="color:gray">
                    <small><?php echo "₹".$original_price;?> </small>
                </s>
                <b style="color:green">
                    <small> <?php echo $offer."% off";?></small><br>
                    <b><small>Save ₹ <?php echo $saved_money; ?></small></b>
                </b><br><br>
                
                <table cellspacing="15">
                    <tr>
                        <td>Highlight:</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>RAM,ROM : </td>
                        <td><?php echo $row['RAM']." | ".$row['INTERNAL-STORAGE'];?></td>
                    </tr>
                    <tr>
                        <td>Display : </td>
                        <td><?php echo $row['DISPLAY'];?></td>
                    </tr>
                    <tr>
                        <td>Camera : </td>
                        <td><?php echo $row['CAMERA'];?></td>
                    </tr>
                    <tr>
                        <td>Processor : </td>
                        <td><?php echo $row['PROCESSOR'];?></td>
                    </tr>
                    <tr>
                        <td>Battery : </td>
                        <td><?php echo $row['BATTERY'];?></td>
                    </tr>
                    <tr>
                        <td>Charger : </td>
                        <td><?php echo $row['CHARGER'];?></td>
                    </tr>
                    <tr>
                        <td>Available : </td>
                        <td>
                            <?php
                                if($stock <= 0)
                                    echo "<font color='red'>Out of stock</font>";
                                else
                                    echo "Yes";
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Description :</td>
                        <td><?php echo $row['DESCRIPTION'];?></td>
                    </tr>
                </table>
            </P>
        </div>
    </div>
</body>
</html>